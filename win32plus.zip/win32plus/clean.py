import glob,os
for i in glob.glob('ROOT/*.HLp'):
    os.remove(i)